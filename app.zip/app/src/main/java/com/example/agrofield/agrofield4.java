package com.example.agrofield;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class agrofield4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agrofield4);

        ListView listView = findViewById(R.id.listView);

        final ArrayList<String> crops = new ArrayList<String>();
        crops.add("ARECANUT");
        crops.add("COCONUT");
        crops.add("SUGARCANE");
        crops.add("RICE");
        crops.add("COTTON");
        crops.add("JOWAR");
        crops.add("MAIZE");
        crops.add("DRY CHILLIES");


        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, crops);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Toast.makeText(getApplicationContext(), crops.get(i), Toast.LENGTH_SHORT).show();
                Toast.makeText(agrofield4.this, Integer.toString(i), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), result.class);
                // intent.putExtra("select the crop",i);

                startActivity(intent);

            }
        });



        Intent intent = getIntent();
        // Toast.makeText(this, Integer.toString(intent.getIntExtra("select the crop",0)), Toast.LENGTH_SHORT).show();

    }
}