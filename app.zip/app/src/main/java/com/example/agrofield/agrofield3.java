package com.example.agrofield;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class agrofield3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agrofield3);

        ListView listView = findViewById(R.id.listView);

        final ArrayList<String> distict = new ArrayList<String>();
        distict.add("SHIMOGA");
        distict.add("CHITRADURGA");
        distict.add("CHIKMAGALUR");
        distict.add("DAVANGERE");
        distict.add("MANDYA");
        distict.add("TUMKUR");


        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, distict);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), agrofield4.class);
                // intent.putExtra("select the crop",i);
                Toast.makeText(agrofield3.this,Integer.toString(i), Toast.LENGTH_SHORT).show();

                startActivity(intent);
            }
        });
        Intent intent2 = getIntent();
        Toast.makeText(this, "Welcome", Toast.LENGTH_SHORT).show();
        //Toast.makeText(this, Integer.toString(intent2.getIntExtra("select the place",0)), Toast.LENGTH_SHORT).show();
    }
}